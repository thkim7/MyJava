
public class SkillDemo {

	public static void main(String[] args) {
		(new Skill()).setVisible(true);		
	}

}
